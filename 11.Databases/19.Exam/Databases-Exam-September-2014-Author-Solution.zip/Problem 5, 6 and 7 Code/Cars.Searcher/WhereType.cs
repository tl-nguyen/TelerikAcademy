﻿namespace Cars.Searcher
{
    public enum WhereType
    {
        Equals,
        Contains,
        GreaterThan,
        LessThan
    }
}